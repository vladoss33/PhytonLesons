#4th program
print(int((123.456*10)%10))
